#include <iostream>
#include <iomanip>
#include "FVISO.h"
#include "conio.h"

// 全局状态变量
bool BreakUDriveGo = false;
bool FromDream = false;

int main() {

    system("chcp 65001");

    //确定盘符
    std::cout << "请输入盘符,如选择E盘，则输入格式为  E:  " << std::endl;
    
    std::wstring Input;
    std::wcin >> Input;

    if (GetDiskNumberFromDriveLetter(Input.c_str()) == -1) {
        std::cout << "查无此盘" << std::endl;
        return -1;
    }

    if (!IsUSBDrive(Input)) {
        std::cout << "此盘非U盘" << std::endl;
        return 0;
    }
    // 弹出确认对话框
    const std::wstring message = L"是否格式化此U盘?";
    int result = MessageBoxW(
        nullptr,
        message.c_str(),
        L"格式化确认",
        MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2
    );

    // 处理用户选择
    BreakUDriveGo = (result == IDYES);
    if (!BreakUDriveGo) {
        std::cout << "已确认退出" << std::endl;
        return 0;
    }

    //格式化
    if (FormatDriveWithCMD(Input)) {
        MessageBoxW(nullptr, L"格式化成功", L"结果", MB_OK);
    }
    else {
        DWORD err = GetLastError();
        std::cout << "格式化错误代码" << err << std::endl;
        return -1;
    }

    std::cout << "注意系统模式: NTFS(1),FAT32(0),输入(0/1)" << std::endl;
    std::cin >> Us;
    std::cout << "注意系统格式，默认MBR，0为GPT，1为MBR,输入(0/1)" << std::endl;
    std::cin >> MBR;

    //烧录
    std::wstring IosFile;
    std::cout << "请输入ISO地址(如\"C:\\pe_system.iso\")：" << std::endl;
    std::wcin >> IosFile;
    // 测试命令行版
    
    std::cout << L"\n开始烧录，请稍候..." << std::endl;
    RuanPand(IosFile, Input);

    std::cout << "如前面无报错,烧录成功" << std::endl;
    getchar();
    return 0;
}