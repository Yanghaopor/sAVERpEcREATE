$diskNumber = 2
$driveLetter = "F:"
$driveLetter = $driveLetter.TrimEnd(':')
$isoPath = ""D:\System\Win10PeX64.iso""

$isoMount = Mount-DiskImage -ImagePath $isoPath -PassThru -NoDriveLetter
$isoVolume = $isoMount | Get-Volume
$wimPath = "$($isoVolume.DriveLetter):\sources\boot.wim"

$diskpartScript = @"
select disk $diskNumber
attributes disk clear readonly
clean
convert mbr
create partition primary
format fs=fat32 quick
active
assign letter=$driveLetter
exit
"@
$diskpartScript | Out-File "$env:TEMP\diskpart_script.txt"
diskpart /s "$env:TEMP\diskpart_script.txt"

dism /Apply-Image /ImageFile:"$wimPath" /Index:1 /ApplyDir:"${driveLetter}:\"
bootsect /nt60 "${driveLetter}:" /force /mbr
Dismount-DiskImage -ImagePath $isoPath
