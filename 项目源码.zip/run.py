import os
import subprocess
import sys
import stat

def is_block_device(path):
    try:
        mode = os.stat(path).st_mode
        return stat.S_ISBLK(mode)
    except FileNotFoundError:
        return False

def create_system_disk(iso_path, drive_path):
    # 检查ISO文件是否存在
    if not os.path.isfile(iso_path):
        raise ValueError(f"ISO文件 '{iso_path}' 不存在。")
    
    # 根据操作系统处理
    if sys.platform.startswith('linux'):
        # 检查目标是否为块设备
        if not is_block_device(drive_path):
            raise ValueError(f"'{drive_path}' 不是一个块设备，请指定正确的设备路径（如 /dev/sdX）。")
        
        # 使用dd命令烧录ISO
        cmd = [
            'sudo', 'dd',
            f'if={iso_path}',
            f'of={drive_path}',
            'bs=4M',
            'status=progress'
        ]
        print("正在烧录ISO到U盘，这可能会覆盖目标设备的所有数据，请确认！")
        print("烧录中...")
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(f"烧录失败：{e}")
            sys.exit(1)
        except FileNotFoundError:
            print("错误：dd命令未找到，请确保已安装coreutils。")
            sys.exit(1)
        print("烧录成功！U盘已准备就绪。")
    
    elif sys.platform == 'win32':
        # Windows部分需要手动操作或第三方工具
        print("Windows平台暂不支持自动化烧录。")
        print("请使用工具如Rufus，并选择ISO和目标U盘。")
        sys.exit(1)
    else:
        print("不支持的操作系统。")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法：python script.py <ISO路径> <U盘设备路径>")
        print("示例（Linux）：python script.py /path/to/image.iso /dev/sdb")
        sys.exit(1)
    create_system_disk(sys.argv[1], sys.argv[2])